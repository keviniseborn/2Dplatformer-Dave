var searchData=
[
  ['update',['update',['../class_game_play.html#a32f780550fae20146e6d6bf844ee3eae',1,'GamePlay::update()'],['../class_movable.html#a4225e9e17fc5bf00cc18d1d124212614',1,'Movable::update()']]]
];
