var searchData=
[
  ['magnitude',['magnitude',['../class_vector2_d.html#a2840db6c516580a39fd5a309d991dae2',1,'Vector2D']]],
  ['movable',['Movable',['../class_movable.html#a053cf48796f1aef5b6f6cb4c6b22db78',1,'Movable']]]
];
